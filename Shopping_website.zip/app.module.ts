import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { ReturnComponent } from './return/return.component';
import { RegisterComponent } from './register/register.component';
import { KidsComponent } from './kids/kids.component';
import { WomenComponent } from './women/women.component';
import { MenComponent } from './men/men.component';

const appRoutes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'feedback', component: FeedbackComponent},
  {path:'contact', component: ContactComponent},
  {path:'register', component: RegisterComponent},
  {path:'return', component: ReturnComponent},
  {path:'kids', component: KidsComponent},
  {path:'home',component:HomeComponent},
  {path:'women',component:WomenComponent},
  {path:'men',component:MenComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FeedbackComponent,
    ContactComponent,
    HomeComponent,
    ReturnComponent,
    RegisterComponent,
    KidsComponent,
    WomenComponent,
    MenComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
